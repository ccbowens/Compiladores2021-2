package compilador;

//@autores: Marcella Coelho Brito Nunes, Camila Carolina Bowens e Felipe Krieger Buche

public class CompiladorPrincipal {

	public static void main(String[] args) {
			Interface umaInterface = new Interface();
			umaInterface.setLocationRelativeTo(null);
			umaInterface.setVisible(true);
			}

}
