package compilador;

public class Token 
{
    private int id;
    private String lexeme;
    private int position;
	

    public Token(int id, String lexeme, int position)
    {
        this.id = id; //classe codificada
        this.lexeme = lexeme; //sequencia reconhecida
        this.position = position; //posicao inicial da sequencia
    }

    public final int getId()
    {
        return id;
    }

    public final String getLexeme()
    {
        return lexeme;
    }

    public final int getPosition()
    {
    	
        return position;
    }
    
    public int getLine(String text) {
    	String [] lines= text.split("\n");
    	return 0;
    }
    public String classePorExtenso() {
            String palavra = null;
            if (this.id == 0){
                palavra = "epsilon";
            }
            if (this.id == 1){
                palavra = "dollar";
            }
            if (this.id == 2 ) {
                palavra = "palavra_reservada";
            }
            if (this.id == 3) {
                palavra = "identificador"; //id_int
            }
            if (this.id == 4){
                palavra = "identificador"; //id_float
            }
            if (this.id == 5){
                palavra = "identificador"; //id_string
            }
            if (this.id == 6){
                palavra = "identificador"; //id_bool
            }
            if (this.id == 7){
                palavra = "constante"; //constante_int
            }
            if (this.id == 8){
                palavra = "constante"; //constante_float
            }
            if (this.id == 9){
                palavra = "constante"; //constante_string
            }
            if (this.id == 10){
                palavra = "palavra reservada"; //pr_AND
            }
            if (this.id == 11){
                palavra = "palavra reservada"; //pr_endIF
            }
            if (this.id == 12){
                palavra = "palavra reservada"; //pr_endWhile
            }
            if (this.id == 13){
                palavra = "palavra reservada"; //pr_false
            }
            if (this.id == 14){
                palavra = "palavra reservada"; //pr_finish
            }
            if (this.id == 15){
                palavra = "palavra reservada"; //pr_if
            }
            if (this.id == 16){
                palavra = "palavra reservada"; //pr_in
            }
            if (this.id == 17){
                palavra = "palavra reservada"; //pr_isFalseDo
            }
            if (this.id == 18){
                palavra = "palavra reservada"; //pr_isTrueDo
            }
            if (this.id == 19){
                palavra = "palavra reservada"; //pr_newLine
            }
            if (this.id == 20){
                palavra = "palavra reservada"; //pr_not
            }
            if (this.id == 21){
                palavra = "palavra reservada"; //pr_or
            }
            if (this.id == 22){
                palavra = "palavra reservada"; //pr_out
            }
            if (this.id == 23){
                palavra = "palavra reservada"; //pr_space
            }
            if (this.id == 24){
                palavra = "palavra reservada"; //pr_tab
            }
            if (this.id == 25){
                palavra = "palavra reservada"; //pr_true
            }
            if (this.id == 26){
                palavra = "palavra reservada"; //pr_while
            }
            if (this.id == 27){
                palavra = "token"; //"["
            }
            if (this.id == 28){
                palavra = "token"; //"]"
            }
            if (this.id == 29){
                palavra = "token"; //"("
            }
            if (this.id == 30){
                palavra = "token"; //")"
            }
            if (this.id == 31){
                palavra = "token"; //"=="
            }
            if (this.id == 32){
                palavra = "token"; //"<>"
            }
            if (this.id == 33){
                palavra = "token"; //"<"
            }
            if (this.id == 34){
                palavra = "token"; //">"
            }
            if (this.id == 35){
                palavra = "token"; //"+"
            }
            if (this.id == 36){
                palavra = "token"; //"-"
            }
            if (this.id == 37){
                palavra = "token"; //"*"
            }
            if (this.id == 38){
                palavra = "token"; //"/"
            }
            if (this.id == 39){
                palavra = "token"; //","
            }
            if (this.id == 40){
                palavra = "token"; //";"
            }
            if (this.id == 41){
                palavra = "token"; //":"
            }
            if (this.id == 42){
                palavra = "token"; //"="
            }
            return palavra;
        }
    

    public String toString()
    {
        return id + classePorExtenso() +" ( "+lexeme+" ) @ "+position;
    };
    
}
