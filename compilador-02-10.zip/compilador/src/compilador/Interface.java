package compilador;



//@autores: Marcella Coelho Brito Nunes, Camila Carolina Bowens e Felipe Krieger Buche


import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JToolBar;
import javax.swing.JSplitPane;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import java.awt.Toolkit;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.JTextPane;

public class Interface extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel Compilador;
	/**
	 * @wbp.nonvisual location=21,659
	 */
	private final JFileChooser fileChooser = new JFileChooser();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface frame = new Interface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Interface() {
		
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\asterisk-symbol.png"));
		setTitle("Compilador - Marcella,Camila,Felipe");
		fileChooser.removeChoosableFileFilter(fileChooser.getChoosableFileFilters()[0]);
		fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("Arquivos de textos (*.txt)", "txt"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		Compilador = new JPanel();
		Compilador.setToolTipText("Compilador");
		Compilador.setBorder(new EmptyBorder(5, 5, 5, 5));
		Compilador.setLayout(new BorderLayout(0, 0));
		setContentPane(Compilador);
		
		JSplitPane splitPane = new JSplitPane();
		splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		Compilador.add(splitPane, BorderLayout.CENTER);
		
		JScrollPane Editor = new JScrollPane();
		Editor.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		Editor.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		splitPane.setLeftComponent(Editor);
		
		JTextArea TextoEditor = new JTextArea();
		Editor.setViewportView(TextoEditor);
		TextoEditor.setBorder(new NumberedBorder());
		
		JScrollPane AreaParaMensagens = new JScrollPane();
		AreaParaMensagens.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		AreaParaMensagens.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		splitPane.setRightComponent(AreaParaMensagens);
		
		JTextArea TextoMensagens = new JTextArea();
		TextoMensagens.setEditable(false);
		AreaParaMensagens.setViewportView(TextoMensagens);
		splitPane.setDividerLocation(400);
		
		JToolBar BarraDeStatus = new JToolBar();
		Compilador.add(BarraDeStatus, BorderLayout.SOUTH);
		
		JTextPane textPane = new JTextPane();
		textPane.setBackground(UIManager.getColor("Button.background"));
		BarraDeStatus.add(textPane);
		
		JToolBar BarraDeFerramentas = new JToolBar();
		BarraDeFerramentas.setOrientation(SwingConstants.VERTICAL);
		Compilador.add(BarraDeFerramentas, BorderLayout.WEST);
		
		JButton Novo = new JButton("Novo [Ctrl-N]      ");
		
		Novo.setBorder(UIManager.getBorder("Button.border"));
		Novo.setIcon(new ImageIcon("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\novo.png"));
		Novo.setActionCommand("Novo");
		
		Novo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TextoEditor.setText("");
				TextoMensagens.setText("");
			}
		});
	
		BarraDeFerramentas.add(Novo);
		
		JButton Abrir = new JButton("Abrir [Ctrl-O]      ");
		
		Abrir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				FileNameExtensionFilter filter = new FileNameExtensionFilter("arquivo de texto", "txt");
				fileChooser.addChoosableFileFilter(filter);
				


				int returnVal = fileChooser.showOpenDialog(Abrir);
			    if (returnVal == JFileChooser.APPROVE_OPTION) {
			        File file = fileChooser.getSelectedFile();
			        try {
			          // What to do with the file, e.g. display it in a TextArea
			
						textPane.setText(file.getAbsolutePath());
			          TextoEditor.read( new FileReader( file.getAbsolutePath() ), null );
			        } catch (IOException ex) {
			          System.out.println("problem accessing file"+file.getAbsolutePath());
			        }
			    } else {
			        System.out.println("File access cancelled by user.");
			    }
			}
		});
		
		Abrir.setBorder(UIManager.getBorder("Button.border"));
		Abrir.setIcon(new ImageIcon("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\abrir.png"));
		BarraDeFerramentas.add(Abrir);
		
		JButton Salvar = new JButton("Salvar [Ctrl-S]    ");
		Salvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textPane.getText() != "") {
					
					try {
						FileWriter fw = new FileWriter( fileChooser.getSelectedFile());
						BufferedWriter bw = new BufferedWriter( fw );
						TextoEditor.write( bw );
						bw.flush();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
					
				}else {
					fileChooser.setDialogTitle("Especifique a pasta para salvar"); 
					fileChooser.showSaveDialog(null);
					
					FileWriter fw;
					try {
						
						fw = new FileWriter( fileChooser.getSelectedFile() + ".txt");
						File currentFile = new File(fileChooser.getSelectedFile() + ".txt");
						textPane.setText(currentFile.getAbsolutePath());
						BufferedWriter bw = new BufferedWriter( fw );
						TextoEditor.write( bw );
						bw.flush();
					} catch (IOException e1) {
						
						e1.printStackTrace();
					}
					
				}
					
				
			}
				
		});
		
		Salvar.setBorder(UIManager.getBorder("Button.border"));
		Salvar.setIcon(new ImageIcon("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\save.png"));
		BarraDeFerramentas.add(Salvar);
		
		JButton Copiar = new JButton("Copiar [Ctrl-C]   ");
		
		Copiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TextoEditor.copy();
			}
		});
		Copiar.setBorder(UIManager.getBorder("Button.border"));
		Copiar.setIcon(new ImageIcon("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\copy.png"));
		BarraDeFerramentas.add(Copiar);
		
		JButton Colar = new JButton("Colar [Ctrl-V]     ");
		Colar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TextoEditor.paste();
			}
		});
		Colar.setBorder(UIManager.getBorder("Button.border"));
		Colar.setIcon(new ImageIcon("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\paste.png"));
		BarraDeFerramentas.add(Colar);
		
		JButton Recortar = new JButton("Recortar [Ctrl-X]");
		Recortar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TextoEditor.cut();
			}
		});
		Recortar.setBorder(UIManager.getBorder("Button.border"));
		Recortar.setIcon(new ImageIcon("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\scissors.png"));
		BarraDeFerramentas.add(Recortar);
		
		JButton Compilar = new JButton("Compilar [F7]     ");
		Compilar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   Lexico lexico = new Lexico();
				   lexico.setInput( TextoEditor.getText());
				   try {
				   Token t = null;
				   while ( (t = lexico.nextToken()) != null ) {
				     TextoMensagens.setText("linha: " + (t.getPosition()+1) + "\n" + "lexema: " + t.classePorExtenso() + "\n" + "classe: "+ t.getLexeme() + "\n" + "Programa compilado com sucesso!");
				   }
			}catch ( LexicalError erro ) {  // tratamento de erros
			     TextoMensagens.setText(erro.getMessage() + " em " + (erro.getPosition()+1));
			     
			} 
				   
		}
			});
		Compilar.setBorder(UIManager.getBorder("Button.border"));
		Compilar.setIcon(new ImageIcon("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\compile.png"));
		BarraDeFerramentas.add(Compilar);
		
		JButton Equipe = new JButton("Equipe [F1]        ");
		Equipe.setBorder(UIManager.getBorder("Button.border"));
		Equipe.setIcon(new ImageIcon("C:\\Users\\tchel\\eclipse-workspace\\compilador\\src\\Icons\\equipe.png"));
		Equipe.setActionCommand("Equipe");
		Equipe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TextoMensagens.setText("Equipe: Marcella Coelho Brito Nunes, Camila Carolina Bowens e Felipe Krieger Buche");
			}
		});
		BarraDeFerramentas.add(Equipe);
		
		
    }
		
	}


